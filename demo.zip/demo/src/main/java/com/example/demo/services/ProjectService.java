package com.example.demo.services;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.demo.domain.Backlog;
import com.example.demo.domain.Client;
import com.example.demo.domain.Project;
import com.example.demo.exceptions.ProjectIdException;
import com.example.demo.exceptions.ProjectNotFoundException;
import com.example.demo.repositories.BacklogRepository;
import com.example.demo.repositories.ClientRepository;
import com.example.demo.repositories.ProjectRepository;

@Service
public class ProjectService {
	
	 @Autowired
	    private ClientRepository clientRepository;
	 
	 
	 @Autowired
	    private ProjectRepository projectRepository;
	 
	 @Autowired
	    private BacklogRepository backlogRepository;
	 
	 //For all below methods,
	 //username comes from security principle.getName, check controller
	 //We dont have to explicitly send username
	 
	 
	    public Project saveOrUpdateProject(Project project,String username){
	    	
//	    	checks done for updating project 
//			Example	    	
//	    	If below is project and username is vandana@mail.com
//	    	{
//	    		  "description": " update jwt project again",
//	    		  "projectIdentifier": "JWTP2",
//	    		  "projectName": "jwt",
//	    		  "id":8
//	    		}

//	    	1. If id is not null, then its updation
//	    	2. Find existing project with identifier JWTP2
//	    	3.Check if that existing project is not null
//	    	4. Check if that existing project's db id is same as project's db id(This is to ensure user passes db id and identifier belonging to same project)
//	    	5. Check if that existing project's projectLeader is same as current logged in user-vandana@mail.com
	    	
	    	if(project.getId() != null){
	             Project existingProject = projectRepository.findByProjectIdentifier(project.getProjectIdentifier().toUpperCase());
	             if (existingProject != null  && 
	                    (!existingProject.getId().equals(project.getId()) || !existingProject.getProjectLeader().equals(username))){
	                 throw new ProjectNotFoundException("Project not found in your account");
	             }else if(existingProject == null){
	                 throw new ProjectNotFoundException("Project with ID: '"+project.getProjectIdentifier()+"' cannot be updated because it doesn't exist");
	             }
	         }
	    	
	    	try{
	    		
	    		 Client user = clientRepository.findByUsername(username);
	             project.setUser(user);
	             project.setProjectLeader(user.getUsername());
	    		 project.setProjectIdentifier(project.getProjectIdentifier().toUpperCase());
	    		 //This is a case of creating new project
	    		 //project object will only have desc name and identifier and maybe dates
	    		 //db id for project will be not set yet(in case of swagger it will be set to 0 , in case of postman if we don't specify id it will be null)
	    		 //In that case we need to create backlog object and set it to project
	    		 //Also set backlog attributes
	    		 
	    		 //if(project.getId()==null) if its ui or postman
	    		//if(project.getId()==0) if its swagger
	    		 if(project.getId()==null){
	                 Backlog backlog = new Backlog();
	                 backlog.setProject(project);
	                 backlog.setProjectIdentifier(project.getProjectIdentifier().toUpperCase());
	                 project.setBacklog(backlog);
	                 //backlog gets saved without doing repo.save()!!!
	                 
	             }

	             //This is the case where project is being updated
	             //We need to explicitly set backlog object to project again 
	    		 
	    		//if(project.getId()!=null) if its ui or postman
	    		//if(project.getId()!=0) if its swagger
	             if(project.getId()!=null){
	                 project.setBacklog(backlogRepository.findByProjectIdentifier(project.getProjectIdentifier().toUpperCase()));
	             }
	             return projectRepository.save(project);
	         }catch (Exception e){
	             throw new ProjectIdException("Project ID '"+project.getProjectIdentifier().toUpperCase()+"' already exists");
	         }
	    }
	    
	    public Project findProjectByIdentifier(String projectId,String username) {
	    	Project project = projectRepository.findByProjectIdentifier(projectId.toUpperCase());
	    	if(project==null) {
	    		throw new ProjectIdException("Project ID '"+projectId+"' does not exist");
	    	}
	    	
	    	//projectLeader has username of person who created the project
	    	//Checking if that is equal to logged in username
	    	
	    	 if(!project.getProjectLeader().equals(username)){
	             throw new ProjectNotFoundException("Project not found in your account");
	         }
	    	 
	    	return project;
	    }
	    
	    public Iterable<Project> findAllProjects(String username){
	    	return projectRepository.findAllByProjectLeader(username);
	    	
	    }
	    
	    public void deleteProjectByIdentifier(String projectId,String username) {
	    	projectRepository.delete(findProjectByIdentifier(projectId, username));
	    }
}
