package com.example.demo.repositories;
import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

import com.example.demo.domain.Client;

@Repository
public interface ClientRepository extends CrudRepository<Client, Long> {
    Client findByUsername(String username);
    Client getById(Long id);
}
