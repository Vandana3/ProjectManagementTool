package com.example.demo.web;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.*;

import com.example.demo.domain.ProjectTask;
import com.example.demo.services.MapValidationErrorService;
import com.example.demo.services.ProjectTaskService;

import javax.validation.Valid;
import java.security.Principal;

@RestController
@RequestMapping("/api/task")
@CrossOrigin
public class ProjectTaskController {

    @Autowired
    private ProjectTaskService projectTaskService;

    @Autowired
    private MapValidationErrorService mapValidationErrorService;

    //principal comes from security, principle.getName() gives us username of logged in person
    //We dont have to explicitly provide any input here

    @PostMapping("/{project_identifier}")
    public ResponseEntity<?> addProjectTask(@Valid @RequestBody ProjectTask projectTask,
                                            BindingResult result, @PathVariable String project_identifier, Principal principal){

        ResponseEntity<?> errorMap = mapValidationErrorService.MapValidationService(result);
        if (errorMap != null) return errorMap;

        ProjectTask projectTask1 = projectTaskService.addProjectTask(project_identifier, projectTask , principal.getName());

        return new ResponseEntity<ProjectTask>(projectTask1, HttpStatus.CREATED);

    }
    
    @PatchMapping("/{project_identifier}/{project_sequence}")
    public ResponseEntity<?> updateProjectTask(@Valid @RequestBody ProjectTask projectTask, BindingResult result,
                                               @PathVariable String project_identifier, @PathVariable String project_sequence , Principal principal ){

        ResponseEntity<?> errorMap = mapValidationErrorService.MapValidationService(result);
        if (errorMap != null) return errorMap;

        ProjectTask updatedTask = projectTaskService.updateProjectTaskByProjectSequence(projectTask,project_identifier,project_sequence,principal.getName());

        return new ResponseEntity<ProjectTask>(updatedTask,HttpStatus.OK);

    }
    
    @GetMapping("/{project_identifier}")
    public Iterable<ProjectTask> getProjectTasks(@PathVariable String project_identifier, Principal principal){

        return projectTaskService.findProjectTasksByProjectIdentifier(project_identifier , principal.getName());

    }
    
    @GetMapping("/{project_identifier}/{project_sequence}")
    public ResponseEntity<?> getProjectTask(@PathVariable String project_identifier, @PathVariable String project_sequence, Principal principal){
        ProjectTask projectTask = projectTaskService.findProjectTaskByProjectSequence(project_identifier, project_sequence,principal.getName());
        return new ResponseEntity<ProjectTask>( projectTask, HttpStatus.OK);
    }
    
    @DeleteMapping("/{project_identifier}/{project_sequence}")
    public ResponseEntity<?> deleteProjectTask(@PathVariable String project_identifier, @PathVariable String project_sequence, Principal principal){
        projectTaskService.deleteProjectTaskByProjectSequence(project_identifier, project_sequence,principal.getName());

        return new ResponseEntity<String>("Project Task "+project_sequence+" was deleted successfully", HttpStatus.OK);
    }


}
