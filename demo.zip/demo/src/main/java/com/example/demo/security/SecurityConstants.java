package com.example.demo.security;

public class SecurityConstants {
	 public static final String SIGN_UP_URLS = "/api/users/**";
	    //public static final String H2_URL = "h2-console/**";
	    public static final String SECRET ="SecretKeyToGenJWTs";
	    //There should be a space after bearer!!
	    public static final String TOKEN_PREFIX= "Bearer ";
	    public static final String HEADER_STRING = "Authorization";
	    public static final long EXPIRATION_TIME = 86400000; //24 hrs
}
