package com.example.demo.services;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;

import com.example.demo.domain.Backlog;
import com.example.demo.domain.Project;
import com.example.demo.domain.ProjectTask;
import com.example.demo.exceptions.ProjectNotFoundException;
import com.example.demo.repositories.BacklogRepository;
import com.example.demo.repositories.ProjectRepository;
import com.example.demo.repositories.ProjectTaskRepository;
import org.springframework.stereotype.Service;

@Service
public class ProjectTaskService {
	@Autowired
    private BacklogRepository backlogRepository;

    @Autowired
    private ProjectTaskRepository projectTaskRepository;

    @Autowired
    private ProjectRepository projectRepository;
    
    @Autowired
    private ProjectService projectService;

    
	 //For all below methods,
	 //username comes from security principle.getName, check controller
	 //We dont have to explicitly send username
    
    
    public ProjectTask addProjectTask(String projectIdentifier, ProjectTask projectTask, String username){


    	
    	Backlog backlog =  projectService.findProjectByIdentifier(projectIdentifier.toUpperCase(), username).getBacklog();
        
        projectTask.setBacklog(backlog);
        
        //we want our project sequence to be like this: PROID-1  PROID-2  ...100 101
      //ProjectSequence is ProjectIdentifier-incValueOfBacklogSequence
        
        Integer BacklogSequence = backlog.getPTSequence();
        // Update the BL SEQUENCE
        BacklogSequence++;
        
        //Set incremented value back
        backlog.setPTSequence(BacklogSequence);
        //Remember backlog object is automatically saved

        projectTask.setProjectSequence(backlog.getProjectIdentifier()+"-"+BacklogSequence);
        projectTask.setProjectIdentifier(backlog.getProjectIdentifier());

        //if(projectTask.getPriority()==0) if its swagger
        //if(projectTask.getPriority()==null) if its postman
        if(projectTask.getPriority()==null||projectTask.getPriority()==0) {
            projectTask.setPriority(3);
        }
        //INITIAL status when status is null
        if(projectTask.getStatus()==""|| projectTask.getStatus()==null){
            projectTask.setStatus("TO_DO");
        }

        return projectTaskRepository.save(projectTask);
    	
    }
    
    
    public ProjectTask updateProjectTaskByProjectSequence(ProjectTask updatedTask, String projectIdentifier, String projectSequence,String username){
        
        //Check for validity by calling findProjectTaskByProjectSequence which validates both
        //projectIdentifier and projectSequence
        ProjectTask projectTask=findProjectTaskByProjectSequence(projectIdentifier,projectSequence,username);
        
        if(projectTask.getId()!=updatedTask.getId()) {
        	throw new ProjectNotFoundException("ProjectTask db id not matching with its identifier and sequence values");
        }
        projectTask = updatedTask;
        //If db ids are same they automatically get updated
        return projectTaskRepository.save(projectTask);
    }
    
    public Iterable<ProjectTask> findProjectTasksByProjectIdentifier(String projectIdentifier, String username){
    	
    	 projectService.findProjectByIdentifier(projectIdentifier, username);
        return projectTaskRepository.findByProjectIdentifierOrderByPriority(projectIdentifier.toUpperCase());
    }
    
    public ProjectTask findProjectTaskByProjectSequence(String projectIdentifier, String projectSequence,String username){

    	projectService.findProjectByIdentifier(projectIdentifier.toUpperCase(), username);

        //make sure that our task exists
        ProjectTask projectTask = projectTaskRepository.findByProjectSequence(projectSequence.toUpperCase());

        if(projectTask == null){
            throw new ProjectNotFoundException("Project Task '"+projectSequence+"' not found");
        }

        //make sure that the backlog/project id in the path corresponds to the right project
        if(!projectTask.getProjectIdentifier().equals(projectIdentifier.toUpperCase())){
            throw new ProjectNotFoundException("Project Task '"+projectSequence+"' does not exist in project: '"+projectIdentifier);
        }
        return projectTask;
    }
    
    
    public void deleteProjectTaskByProjectSequence(String projectIdentifier, String projectSequence,String username){
        //Check for validity by calling findProjectTaskByProjectSequence which validates both
        //projectIdentifier and projectSequence
        ProjectTask projectTask=findProjectTaskByProjectSequence(projectIdentifier,projectSequence,username);


        projectTaskRepository.delete(projectTask);
    }
}
