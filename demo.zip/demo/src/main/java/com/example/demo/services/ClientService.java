package com.example.demo.services;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import com.example.demo.domain.Client;
import com.example.demo.exceptions.UsernameAlreadyExistsException;
import com.example.demo.repositories.ClientRepository;

@Service
public class ClientService {

	@Autowired
    private ClientRepository clientRepository;
	
    @Autowired
    private BCryptPasswordEncoder bCryptPasswordEncoder;

    public Client saveUser (Client newUser){
    	
    	try {
    	      newUser.setPassword(bCryptPasswordEncoder.encode(newUser.getPassword()));
    	      
    	      //confirm password is set transient which means it will not be a field in db
    	      //After verifying the password and confirm password in controller we will set confirm password to ""
    	      //So that way we won't see confirm password in response too
    	      newUser.setConfirmPassword("");
    	      //Username has to be unique (exception)

    	        // Make sure that password and confirmPassword match
    	        // We don't persist or show the confirmPassword
    	      return clientRepository.save(newUser);
    	}catch(Exception e) {
    		throw new UsernameAlreadyExistsException("Username '"+newUser.getUsername()+"' already exists");
    	}

    }
}
