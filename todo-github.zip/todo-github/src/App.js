import React, { Component } from "react";
import "./App.css";
import jwt_decode from "jwt-decode";
import { BrowserRouter as Router, Route, Switch } from "react-router-dom";

import Dashboard from "./components/Dashboard";
import Header from "./components/Layout/Header";
import AddProject from "./components/Project/AddProject";
import UpdateProject from "./components/Project/UpdateProject";
import ProjectBoard from "./components/ProjectBoard/ProjectBoard";
import AddProjectTask from "./components/ProjectBoard/ProjectTasks/AddProjectTask";
import UpdateProjectTask from "./components/ProjectBoard/ProjectTasks/UpdateProjectTask";
import Home from "./components/Layout/Home";
import Register from "./components/UserManagement/Register";
import Login from "./components/UserManagement/Login";
import reducers from './reducers';
import store from "./store";
import setJWTToken from "./securityUtils/setJWTToken";
import { SET_CURRENT_USER } from "./actions/types";
import { logout } from "./actions/securityActions";
import SecuredRoute from "./securityUtils/SecureRoute";

//local storage->inspect-application-storage-localStorage-localhost->our token is stored there
//When user refreshes the page after logging in, he should still be logged in and access apis,
//Headers should still be set
//The token will be saved in localStorage even after user refreshes the page
const jwtToken = localStorage.jwtToken;

if (jwtToken) {
  setJWTToken(jwtToken);
  const decoded_jwtToken = jwt_decode(jwtToken);
  store.dispatch({
    type: SET_CURRENT_USER,
    payload: decoded_jwtToken
  });

  const currentTime = Date.now() / 1000;
  if (decoded_jwtToken.exp < currentTime) {
    //handle logout
    store.dispatch(logout());
    window.location.href = "/";
  }
}

//Wrap secured routes with switch, if user is not logged in for below routes,
//they will be redirected to login

class App extends Component {
  render() {
    return (
      <Router>
        <div className="App">
          <Header />

          <Route exact path="/" component={Home} />
          <Route exact path="/register" component={Register} />
          <Route exact path="/login" component={Login} />

          <Switch>
          <SecuredRoute exact path="/dashboard" component={Dashboard} />
          <SecuredRoute exact path="/addProject" component={AddProject} />
          <SecuredRoute exact path="/updateProject/:id" component={UpdateProject} />
          <SecuredRoute exact path="/projectBoard/:id" component={ProjectBoard} />
            <SecuredRoute
              exact
              path="/addProjectTask/:id"
              component={AddProjectTask}
            />
            <SecuredRoute
              exact
              path="/updateProjectTask/:project_identifier/:project_sequence"
              component={UpdateProjectTask}
            />
            </Switch>
        </div>
      </Router>
    );
  }
}

export default App;
