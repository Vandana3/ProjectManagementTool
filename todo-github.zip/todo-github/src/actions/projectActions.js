import axios from "axios";

import { GET_ERRORS, GET_PROJECTS, GET_PROJECT, DELETE_PROJECT } from "./types";

//When we createProject
//Very important!! When we submit wrong values or empty values
// the error object from db side (check messages inside Entity class-above each column)
//is held in err.response.data(inside catch block in projectActions


export const createProject = (project, history) => async dispatch => {
  try {
    const res = await axios.post("/api/project", project);
    history.push("/dashboard");

    //If everything worked fine then dispatch get_errors with empty payload
    //Just to make sure error object is made empty
    //Code worked fine without this piece of code(from lines 18 to 21)
    dispatch({
      type: GET_ERRORS,
      payload: {}
    });

//Once user clicks on update Project Info on dashboard, the project object in redux store will be set to that project which user clicked on
//But after updation is done ,after form is submitted we don't want project object in store to hold that info anymore
//So make project object null

    dispatch({
      type: GET_PROJECT,
      payload: {}
    });

  } catch (err) {
    dispatch({
      type: GET_ERRORS,
      payload: err.response.data
    });
  }
};

export const getProjects = () => async dispatch => {
  const res = await axios.get("/api/project/all");
  dispatch({
    type: GET_PROJECTS,
    payload: res.data
  });
};

//When we get project
//If wrong project id is passed in backend will throw exception
//In frontened we just redirect user to dashboard
export const getProject = (id, history) => async dispatch => {
  try {
    const res = await axios.get(`/api/project/${id}`);
    dispatch({
      type: GET_PROJECT,
      payload: res.data
    });
  } catch (error) {
    history.push("/dashboard");
  }
};


export const deleteProject = id => async dispatch => {
 if (
    window.confirm(
      "Are you sure? This will delete the project and all the data related to it"
    )
  ) {
    await axios.delete(`/api/project/${id}`);
    dispatch({
      type: DELETE_PROJECT,
      payload: id
    });
  }
};