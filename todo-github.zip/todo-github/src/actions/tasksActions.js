import axios from "axios";
import { GET_ERRORS, GET_PROJECT_TASKS, GET_PROJECT_TASK ,DELETE_PROJECT_TASK} from "./types";

//When user directly goes to this url and passes wrong project_identifier
//error object will be populated with exception message we had set in backend
//ie project not found
//error will also be populated if nonBlank fields are blank
export const addProjectTask = (
  project_identifier,
  project_task,
  history
) => async dispatch => {
	try{
		    await axios.post(`/api/task/${project_identifier}`, project_task);
  		    history.push(`/projectBoard/${project_identifier}`);
  		    dispatch({
      			type: GET_ERRORS,
      			payload: {}
    		});
	}catch(err){
		dispatch({
      	type: GET_ERRORS,
      	payload: err.response.data
    	});
	}
};

//When user directly goes to this url and passes wrong project_identifier,
//project_tasks for this project_identifier will be empty and error object will be populated with exception message we had set in backend
//ie Project with ID: '{project_identifier}' does not exist
export const getProjectTasks = project_identifier => async dispatch => {
  try {
    const res = await axios.get(`/api/task/${project_identifier}`);
    dispatch({
      type: GET_PROJECT_TASKS,
      payload: res.data
    });
  } catch (err) {
  	 dispatch({
      type: GET_ERRORS,
      payload: err.response.data
    });
  }
};



export const getProjectTask = (
  project_identifier,
  project_sequence,
  history
) => async dispatch => {
  try {
    const res = await axios.get(`/api/task/${project_identifier}/${project_sequence}`);
    dispatch({
      type: GET_PROJECT_TASK,
      payload: res.data
    });
  } catch (err) {
    history.push("/dashboard");
  }
};


export const updateProjectTask = (
  project_identifier,
  project_sequence,
  project_task,
  history
) => async dispatch => {
  try {
    await axios.patch(`/api/task/${project_identifier}/${project_sequence}`, project_task);
    history.push(`/projectBoard/${project_identifier}`);
    dispatch({
      type: GET_ERRORS,
      payload: {}
    });

    dispatch({
      type: GET_PROJECT_TASK,
      payload: {}
    });
  } catch (err) {
    dispatch({
      type: GET_ERRORS,
      payload: err.response.data
    });
  }
};


export const deleteProjectTask = (project_identifier, project_sequence) => async dispatch => {
  if (
    window.confirm(
      `You are deleting project task ${project_sequence}, this action cannot be undone`
    )
  ) {
    await axios.delete(`/api/task/${project_identifier}/${project_sequence}`);
    dispatch({
      type: DELETE_PROJECT_TASK,
      payload: project_sequence
    });
  }
};