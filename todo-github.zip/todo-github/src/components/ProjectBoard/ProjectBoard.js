import React, { Component } from "react";
import { Link } from "react-router-dom";
import { connect } from "react-redux";

import { getProjectTasks } from "../../actions/tasksActions";
import Backlog from "./Backlog";

class ProjectBoard extends Component {

 constructor() {
    super();
    this.state = {
      errors: {}
    };
  }

//When user directly goes to this url and passes wrong project_identifier or 
//project_identifier that does not exist
//getProjectTasks action will be called with this wrong project_identifier,
//project_tasks for this project_identifier will be empty and error object will be populated

//Or if there are simply no project_tasks for that project 
//we should return No Project Tasks on this board

  componentWillReceiveProps(nextProps) {
    if (nextProps.errors) {
      this.setState({ errors: nextProps.errors });
    }
  }

   componentDidMount() {
    const { id } = this.props.match.params;
    this.props.getProjectTasks(id);
  }

  render() {
    const { id } = this.props.match.params;
    const { project_tasks } = this.props.task;
    const { errors } = this.state;

    let BoardContent;
    const boardAlgorithm = (errors, project_tasks) => {
      if (project_tasks.length < 1) {
        if (errors.projectNotFound) {
          return (
            <div className="alert alert-danger text-center" role="alert">
              {errors.projectNotFound}
            </div>
          );
        }else if (errors.projectIdentifier) {
          return (
            <div className="alert alert-secondary text-center" role="alert">
              {errors.projectIdentifier}
            </div>
          );
        } else {
          return (
            <div className="alert alert-secondary text-center" role="alert">
              No Project Tasks on this board
            </div>
          );
        }
      } else {
        return <Backlog project_tasks_prop={project_tasks} />;
      }
    };

    BoardContent = boardAlgorithm(errors, project_tasks);

    return (
      <div className="container">
        <Link to={`/addProjectTask/${id}`} className="btn btn-secondary mb-3">
          <i className="fas fa-plus-circle"> Create Project Task</i>
        </Link>
        <br />
        <hr />
        {BoardContent}
      </div>
    );
  }
}

const mapStateToProps = state => ({
  task: state.task,
  errors: state.errors
});

export default connect(
  mapStateToProps,
  { getProjectTasks }
)(ProjectBoard);
 